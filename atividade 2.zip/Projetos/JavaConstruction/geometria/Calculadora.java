﻿package geometria;

import java.util.Scanner;

public class Calculadora {

    private double lado;
    private double base;
    private double altura;
    private double raio;
    private int opcao;

    public void menu() {
        System.out.println("🟦 Calcular Área do Quadrado");
        System.out.println("▭ Calcular Área do Retângulo");
        System.out.println("△ Calcular Área do Triângulo");
        System.out.println("⚪ Calcular Área do Círculo");
        System.out.println("🚪 Sair");
    }

    public void executar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Escolha uma opção (1-Quadrado, 2-Retângulo, 3-Triângulo, 4-Círculo, 5-Sair): ");
        opcao = sc.nextInt();

        switch (opcao) {
            case 1:
                System.out.print("Digite o lado do quadrado: ");
                lado = sc.nextDouble();
                double areaQuadrado = lado * lado;
                System.out.printf("A área do quadrado é: %.2f\n", areaQuadrado);
                break;

            case 2:
                System.out.print("Digite a base do retângulo: ");
                base = sc.nextDouble();
                System.out.print("Digite a altura do retângulo: ");
                altura = sc.nextDouble();
                double areaRetangulo = base * altura;
                System.out.printf("A área do retângulo é: %.2f\n", areaRetangulo);
                break;

            case 3:
                System.out.print("Digite a base do triângulo: ");
                base = sc.nextDouble();
                System.out.print("Digite a altura do triângulo: ");
                altura = sc.nextDouble();
                double areaTriangulo = (base * altura) / 2;
                System.out.printf("A área do triângulo é: %.2f\n", areaTriangulo);
                break;

            case 4:
                System.out.print("Digite o raio do círculo: ");
                raio = sc.nextDouble();
                double areaCirculo = 3.14 * raio * raio;
                System.out.printf("A área do círculo é: %.2f\n", areaCirculo);
                break;

            case 5:
                System.out.println("Saindo do programa...");
                break;

            default:
                System.out.println("Opção inválida! Tente novamente.");
                break;
        }

        sc.close();
    }
}
